--
-- PostgreSQL database dump
--

\restrict nkuBStdSIgqvAKadeVl1bhdF1aoGcKwUhDpAW5oG5h9oN8KvnaJfmnSJfro6oSw

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    actor_id integer,
    actor_email character varying(120),
    actor_ip character varying(45),
    resource_type character varying(50),
    resource_id character varying(255),
    resource_name character varying(255),
    action character varying(50) NOT NULL,
    description text,
    old_values json,
    new_values json,
    context json,
    status character varying(20),
    error_message text,
    created_at timestamp without time zone,
    device_id character varying(100)
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: command_acknowledgments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.command_acknowledgments (
    id integer NOT NULL,
    command_id character varying(36) NOT NULL,
    device_id character varying(100) NOT NULL,
    ack_type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    message text,
    created_at timestamp without time zone,
    result_data json
);


ALTER TABLE public.command_acknowledgments OWNER TO postgres;

--
-- Name: command_acknowledgments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.command_acknowledgments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.command_acknowledgments_id_seq OWNER TO postgres;

--
-- Name: command_acknowledgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.command_acknowledgments_id_seq OWNED BY public.command_acknowledgments.id;


--
-- Name: command_executions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.command_executions (
    id integer NOT NULL,
    command_id character varying(36) NOT NULL,
    command_type character varying(50) NOT NULL,
    device_id character varying(100),
    target_type character varying(20),
    payload json NOT NULL,
    status character varying(20),
    delivery_status character varying(20),
    execution_status character varying(20),
    created_at timestamp without time zone,
    sent_at timestamp without time zone,
    delivered_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    result_data json,
    error_message text,
    created_by character varying(255),
    retry_count integer,
    max_retries integer,
    timeout_seconds integer
);


ALTER TABLE public.command_executions OWNER TO postgres;

--
-- Name: command_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.command_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.command_executions_id_seq OWNER TO postgres;

--
-- Name: command_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.command_executions_id_seq OWNED BY public.command_executions.id;


--
-- Name: parameter_stream; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parameter_stream (
    id integer NOT NULL,
    parameter_id integer NOT NULL,
    value double precision NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    synced boolean
);


ALTER TABLE public.parameter_stream OWNER TO postgres;

--
-- Name: parameter_stream_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parameter_stream_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parameter_stream_id_seq OWNER TO postgres;

--
-- Name: parameter_stream_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parameter_stream_id_seq OWNED BY public.parameter_stream.id;


--
-- Name: parameters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parameters (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    unit character varying(20) NOT NULL,
    description text,
    enabled boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.parameters OWNER TO postgres;

--
-- Name: parameters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parameters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parameters_id_seq OWNER TO postgres;

--
-- Name: parameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parameters_id_seq OWNED BY public.parameters.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    role_id integer NOT NULL,
    resource character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: system_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_config (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text NOT NULL,
    description character varying(255),
    category character varying(50),
    data_type character varying(20),
    is_sensitive boolean,
    version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    updated_by character varying(100)
);


ALTER TABLE public.system_config OWNER TO postgres;

--
-- Name: system_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_config_id_seq OWNER TO postgres;

--
-- Name: system_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_config_id_seq OWNED BY public.system_config.id;


--
-- Name: telemetry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telemetry (
    id integer NOT NULL,
    device_id character varying(255) NOT NULL,
    parameter_id integer NOT NULL,
    parameter_name character varying(255) NOT NULL,
    value double precision NOT NULL,
    unit character varying(50),
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.telemetry OWNER TO postgres;

--
-- Name: telemetry_buffer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telemetry_buffer (
    id integer NOT NULL,
    device_id character varying(255) NOT NULL,
    parameter_id integer NOT NULL,
    parameter_name character varying(255) NOT NULL,
    value double precision NOT NULL,
    unit character varying(50),
    "timestamp" timestamp without time zone NOT NULL,
    synced boolean
);


ALTER TABLE public.telemetry_buffer OWNER TO postgres;

--
-- Name: telemetry_buffer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telemetry_buffer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telemetry_buffer_id_seq OWNER TO postgres;

--
-- Name: telemetry_buffer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telemetry_buffer_id_seq OWNED BY public.telemetry_buffer.id;


--
-- Name: telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telemetry_id_seq OWNER TO postgres;

--
-- Name: telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telemetry_id_seq OWNED BY public.telemetry.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    name character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean,
    avatar_url text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: command_acknowledgments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.command_acknowledgments ALTER COLUMN id SET DEFAULT nextval('public.command_acknowledgments_id_seq'::regclass);


--
-- Name: command_executions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.command_executions ALTER COLUMN id SET DEFAULT nextval('public.command_executions_id_seq'::regclass);


--
-- Name: parameter_stream id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameter_stream ALTER COLUMN id SET DEFAULT nextval('public.parameter_stream_id_seq'::regclass);


--
-- Name: parameters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameters ALTER COLUMN id SET DEFAULT nextval('public.parameters_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: system_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_config ALTER COLUMN id SET DEFAULT nextval('public.system_config_id_seq'::regclass);


--
-- Name: telemetry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telemetry ALTER COLUMN id SET DEFAULT nextval('public.telemetry_id_seq'::regclass);


--
-- Name: telemetry_buffer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telemetry_buffer ALTER COLUMN id SET DEFAULT nextval('public.telemetry_buffer_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, event_type, severity, actor_id, actor_email, actor_ip, resource_type, resource_id, resource_name, action, description, old_values, new_values, context, status, error_message, created_at, device_id) FROM stdin;
1	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:25:59.339507	\N
2	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:25:59.63172	\N
3	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:25:59.834665	\N
4	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:02.935629	\N
5	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:04.611383	\N
6	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:05.983691	\N
7	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:08.983719	\N
8	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:09.48417	\N
9	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:11.98316	\N
10	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:14.482917	\N
11	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:14.983992	\N
12	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:17.984968	\N
13	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:18.960103	\N
14	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:19.491191	\N
15	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:20.984798	\N
16	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:23.984026	\N
17	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:24.486562	\N
18	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:26.982897	\N
19	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:29.488527	\N
20	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:29.984728	\N
21	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:32.94954	\N
22	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:32.985396	\N
23	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:34.484324	\N
24	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:35.983206	\N
25	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:38.984664	\N
26	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:39.48472	\N
27	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:41.984546	\N
28	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:44.483794	\N
29	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:44.983649	\N
30	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:47.985413	\N
31	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:48.998938	\N
32	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:49.483899	\N
33	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:50.983468	\N
34	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:53.992528	\N
35	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:26:54.484075	\N
36	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:26.755365	\N
37	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:27.162482	\N
38	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:27.339678	\N
39	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:30.447378	\N
40	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:32.499284	\N
41	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:33.489744	\N
42	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:36.483765	\N
43	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:37.486444	\N
44	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:39.490474	\N
45	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:42.482915	\N
46	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:42.49635	\N
47	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:44.426557	\N
48	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:44.63001	\N
49	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:45.483452	\N
50	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:47.483495	\N
51	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:48.484852	\N
52	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:51.48318	\N
53	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:52.483558	\N
54	login_failed	warning	\N	admin@precisionpulse.com	127.0.0.1	user	\N	admin@precisionpulse.com	login	Login failed for user admin@precisionpulse.com	null	null	null	failure	Invalid credentials	2026-03-19 04:31:54.49572	\N
\.


--
-- Data for Name: command_acknowledgments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.command_acknowledgments (id, command_id, device_id, ack_type, status, message, created_at, result_data) FROM stdin;
\.


--
-- Data for Name: command_executions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.command_executions (id, command_id, command_type, device_id, target_type, payload, status, delivery_status, execution_status, created_at, sent_at, delivered_at, started_at, completed_at, result_data, error_message, created_by, retry_count, max_retries, timeout_seconds) FROM stdin;
\.


--
-- Data for Name: parameter_stream; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parameter_stream (id, parameter_id, value, "timestamp", synced) FROM stdin;
\.


--
-- Data for Name: parameters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parameters (id, name, unit, description, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, role_id, resource, action, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, created_at) FROM stdin;
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_config (id, key, value, description, category, data_type, is_sensitive, version, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: telemetry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telemetry (id, device_id, parameter_id, parameter_name, value, unit, "timestamp") FROM stdin;
\.


--
-- Data for Name: telemetry_buffer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telemetry_buffer (id, device_id, parameter_id, parameter_name, value, unit, "timestamp", synced) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, password_hash, role, is_active, avatar_url, created_at, updated_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 54, true);


--
-- Name: command_acknowledgments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.command_acknowledgments_id_seq', 1, false);


--
-- Name: command_executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.command_executions_id_seq', 1, false);


--
-- Name: parameter_stream_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parameter_stream_id_seq', 1, true);


--
-- Name: parameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parameters_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: system_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_config_id_seq', 1, false);


--
-- Name: telemetry_buffer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telemetry_buffer_id_seq', 1, false);


--
-- Name: telemetry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telemetry_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: command_acknowledgments command_acknowledgments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.command_acknowledgments
    ADD CONSTRAINT command_acknowledgments_pkey PRIMARY KEY (id);


--
-- Name: command_executions command_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.command_executions
    ADD CONSTRAINT command_executions_pkey PRIMARY KEY (id);


--
-- Name: parameter_stream parameter_stream_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameter_stream
    ADD CONSTRAINT parameter_stream_pkey PRIMARY KEY (id);


--
-- Name: parameters parameters_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameters
    ADD CONSTRAINT parameters_name_key UNIQUE (name);


--
-- Name: parameters parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameters
    ADD CONSTRAINT parameters_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (id);


--
-- Name: telemetry_buffer telemetry_buffer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telemetry_buffer
    ADD CONSTRAINT telemetry_buffer_pkey PRIMARY KEY (id);


--
-- Name: telemetry telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telemetry
    ADD CONSTRAINT telemetry_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_config_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_config_category ON public.system_config USING btree (category);


--
-- Name: idx_config_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_config_key ON public.system_config USING btree (key);


--
-- Name: idx_parameter_stream_param_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parameter_stream_param_id ON public.parameter_stream USING btree (parameter_id);


--
-- Name: idx_parameter_stream_synced; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parameter_stream_synced ON public.parameter_stream USING btree (synced);


--
-- Name: idx_parameter_stream_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parameter_stream_timestamp ON public.parameter_stream USING btree ("timestamp");


--
-- Name: ix_audit_logs_actor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_actor_id ON public.audit_logs USING btree (actor_id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_device_id ON public.audit_logs USING btree (device_id);


--
-- Name: ix_audit_logs_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_event_type ON public.audit_logs USING btree (event_type);


--
-- Name: ix_audit_logs_resource_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_resource_id ON public.audit_logs USING btree (resource_id);


--
-- Name: ix_command_acknowledgments_command_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_command_acknowledgments_command_id ON public.command_acknowledgments USING btree (command_id);


--
-- Name: ix_command_acknowledgments_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_command_acknowledgments_device_id ON public.command_acknowledgments USING btree (device_id);


--
-- Name: ix_command_executions_command_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_command_executions_command_id ON public.command_executions USING btree (command_id);


--
-- Name: ix_command_executions_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_command_executions_device_id ON public.command_executions USING btree (device_id);


--
-- Name: ix_parameter_stream_parameter_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parameter_stream_parameter_id ON public.parameter_stream USING btree (parameter_id);


--
-- Name: ix_parameter_stream_synced; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parameter_stream_synced ON public.parameter_stream USING btree (synced);


--
-- Name: ix_parameter_stream_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parameter_stream_timestamp ON public.parameter_stream USING btree ("timestamp");


--
-- Name: ix_system_config_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_config_category ON public.system_config USING btree (category);


--
-- Name: ix_system_config_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_system_config_key ON public.system_config USING btree (key);


--
-- Name: ix_telemetry_buffer_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_telemetry_buffer_device_id ON public.telemetry_buffer USING btree (device_id);


--
-- Name: ix_telemetry_buffer_synced; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_telemetry_buffer_synced ON public.telemetry_buffer USING btree (synced);


--
-- Name: ix_telemetry_buffer_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_telemetry_buffer_timestamp ON public.telemetry_buffer USING btree ("timestamp");


--
-- Name: ix_telemetry_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_telemetry_device_id ON public.telemetry USING btree (device_id);


--
-- Name: ix_telemetry_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_telemetry_timestamp ON public.telemetry USING btree ("timestamp");


--
-- Name: permissions permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict nkuBStdSIgqvAKadeVl1bhdF1aoGcKwUhDpAW5oG5h9oN8KvnaJfmnSJfro6oSw

